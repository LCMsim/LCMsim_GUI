i_batch=0
i_model=2
i_mesh=1
mypath=joinpath(pwd())
repositorypath="D:\\work\\LCMsim_v2_20240422\\LCMsim_v2.jl"
guipath="D:\\work\\LCMsim_v2_20240422\\LCMsim_GUI\\gui_and_cases\\gui"

include(joinpath(guipath,"lcmsim_v2_gui_gtk4.jl"))