#i_batch=0
#i_model=2
#i_mesh=1
#mypath=joinpath(pwd())
#repositorypath="D:\\work\\github\\LCMsim_v2.jl"
#guipath="D:\\work\\github\\LCMsim_GUI\\gui_and_cases\\gui"
#
#include(joinpath(guipath,"lcmsim_v2_gui_gtk4.jl"))
#include(joinpath(guipath,"lcmsim_v2_gui.jl"))

include(joinpath("D:\\work\\github\\LCMsim_GUI\\gui_and_cases\\gui","lcmsim_v2_gui_gtk4.jl"))

