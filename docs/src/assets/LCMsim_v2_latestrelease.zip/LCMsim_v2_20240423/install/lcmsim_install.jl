import Pkg
Pkg.add(["HDF5","CSV","JLD2","ProgressMeter","GeometryBasics","LinearAlgebra","StaticArraysCore","Printf","Gtk4","Gtk4Makie","Makie","GtkObservables","NativeFileDialog","Glob","FileIO"])
